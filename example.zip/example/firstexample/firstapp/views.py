from django.shortcuts import render
from .models import *

# Create your views here.


def home(request):
    return render(request, 'home.html')

def view_data(request):

    data=table_data.objects.all()

    return render(request,"table.html",{"sample_data":data})


def html_form(request):
    if request.method == 'POST':
        name=request.POST.get("name")
        email=request.POST.get("email")

        return render(request,"display.html",{"Name":name,"Email":email})

    return render(request,'form.html')


def dbform(request):
    if request.method == 'POST':
        name=request.POST.get("name")
        age=request.POST.get("age")
        gender =request.POST.get("gender")

        table_data1.objects.create(Name=name,Age=age,Gender=gender)

        x={"message":"submitted successfully"}
        return render(request,"form1.html",x)


    return render(request,'form1.html')