from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(table_data)
admin.site.register(table_data1)

