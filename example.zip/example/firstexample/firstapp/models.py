from django.db import models

# Create your models here.


class table_data(models.Model):
    name= models.CharField(max_length=30)
    age = models.IntegerField()
    gender = models.CharField(max_length=25)
    contact = models.IntegerField(max_length=10)


class table_data1(models.Model):
    Name = models.CharField(max_length=30)
    Age = models.IntegerField()
    Gender = models.CharField(max_length=25)
